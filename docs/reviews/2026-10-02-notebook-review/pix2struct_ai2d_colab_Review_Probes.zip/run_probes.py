"""Row 62 review probes for tutorials/pix2struct_ai2d_colab.ipynb (pix2struct-ai2d-pipeline @ origin/main).

CPU only (CUDA_VISIBLE_DEVICES=-1). REDUCED SCALE: the adaptation probes use the repository's own
3-layer, 32-wide randomly initialised Pix2Struct (as tests/test_adaptation_model.py builds it) on 12 tiny
drawn diagrams -- never the pinned 282M checkpoint, never the AI2D shard. They test the pipeline's state
semantics, not answer quality.

Usage: python run_probes.py <repo_root> <out_dir>
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
NB = REPO / "tutorials" / "pix2struct_ai2d_colab.ipynb"
results: dict = {"repo_root": str(REPO), "env": {"CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")}}


def save():
    (OUT / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


# ---------------------------------------------------------------- static probes (source inspection)
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
md = ["".join(c["source"]) for c in cells if c["cell_type"] == "markdown"]
code = [(i, "".join(c["source"])) for i, c in enumerate(cells) if c["cell_type"] == "code"]
alltext = "\n".join("".join(c["source"]) for c in cells)
compile_errors = []
for i, src in code:
    try:
        compile(src, f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append({"cell": i, "error": str(exc)})
blob = subprocess.run(["git", "-C", str(REPO), "rev-parse", "HEAD:tutorials/pix2struct_ai2d_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
results["static"] = {
    "nbformat": [nb.get("nbformat"), nb.get("nbformat_minor")],
    "cells": len(cells), "code_cells": len(code),
    "compile_errors": compile_errors,
    "notebook_blob": blob,
    "metadata_dimer": nb["metadata"].get("dimer"),
    "outputs_present": sum(bool(c.get("outputs")) for c in cells if c["cell_type"] == "code"),
    "double_brace_in_markdown": [{"cell": i, "snippet": m.group(0)} for i, c in enumerate(cells)
                                 if c["cell_type"] == "markdown"
                                 for m in re.finditer(r"\{\{[^}]*\}\}", "".join(c["source"]))],
    "guided_markers": {k: bool(re.search(p, alltext, re.I)) for k, p in {
        "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
        "troubleshooting": r"troubleshoot", "infrastructure_label": r"infrastructure",
        "predict_prompt": r"\bpredict\b(?!ion)|make a prediction", "check_your_reasoning": r"check your reasoning|<details",
        "what_to_notice": r"what to notice|expected result|look for",
        "conclusion_template": r"conclusion template|your conclusion|write.*conclusion"}.items()},
    "cellView_form_cells": sum(c.get("metadata", {}).get("cellView") == "form" for c in cells),
    "embedded_module_cell_chars": {c["metadata"]["dimer"]["embedded_module"]: len("".join(c["source"]))
                                   for c in cells if c.get("metadata", {}).get("dimer", {}).get("embedded_module")},
    "env_var_DIMER_NOTEBOOK_CI_PREINSTALLED_in_code": "DIMER_NOTEBOOK_CI_PREINSTALLED" in "".join(s for _, s in code),
    "env_var_documented_in_markdown": any("DIMER_NOTEBOOK_CI_PREINSTALLED" in m for m in md),
    "restart_instruction_in_install_cell": "Restart the runtime" in code[0][1],
    "byod_uses_upload_dialog": "files.upload()" in alltext,
    "byod_location_field": bool(re.search(r"BYOD_(ZIP_)?PATH\s*=.*@param", alltext)),
    "warnings_filterwarnings": "filterwarnings" in alltext,
    "spec_version_declared": nb["metadata"].get("dimer", {}).get("notebook_spec"),
    "cpu_runtime_estimate_in_markdown": bool(re.search(r"(minutes|hours?)\b.*CPU|CPU.*\b(minutes|hours?)", "\n".join(md[:2]))),
}
save()

# ---------------------------------------------------------------- BYOD branch replay (no model)
sys.path.insert(0, str(REPO / "src"))
from PIL import Image  # noqa: E402


def byod_block(uploaded: dict, work: Path):
    """Verbatim logic of the notebook's Section 4 BYOD branch, with files.upload() replaced by `uploaded`."""
    from pix2struct_ai2d_pipeline.samples import load_byod_dataset, split_dataset
    file_name, payload = next(iter(uploaded.items()))
    byod_dir = work / "byod"
    byod_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        for member in archive.infolist():
            name = Path(member.filename).name
            if member.is_dir() or not name or name.startswith("."):
                continue
            (byod_dir / name).write_bytes(archive.read(member))
    records_file = next(p for p in (byod_dir / "records.jsonl", byod_dir / "records.json") if p.is_file())
    records = load_byod_dataset(records_file)
    return split_dataset(records, seed=42, base_dir=byod_dir), byod_dir


def png(colour):
    buf = io.BytesIO()
    Image.new("RGB", (64, 64), colour).save(buf, format="PNG")
    return buf.getvalue()


def make_zip(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n, d in entries:
            z.writestr(n, d)
    return buf.getvalue()


def recs(n, image_for=lambda i: f"img{i}.png"):
    return "\n".join(json.dumps({"id": f"q{i}", "image": image_for(i), "question": "What colour?",
                                 "options": ["red", "blue"], "answer": i % 2}) for i in range(n))


byod = {}
import tempfile  # noqa: E402
cases = {
    "valid_16": make_zip([("records.jsonl", recs(16))] + [(f"img{i}.png", png("red" if i % 2 == 0 else "blue")) for i in range(16)]),
    "no_records_file": make_zip([(f"img{i}.png", png("red")) for i in range(16)]),
    "empty_upload_cancelled": None,
    "nested_folder_paths": make_zip([("records.jsonl", recs(16, lambda i: f"images/img{i}.png"))] + [(f"images/img{i}.png", png("red")) for i in range(16)]),
    "answer_out_of_range": make_zip([("records.jsonl", recs(16).replace('"answer": 1', '"answer": 5'))] + [(f"img{i}.png", png("red")) for i in range(16)]),
}
for name, payload in cases.items():
    with tempfile.TemporaryDirectory() as td:
        uploaded = {} if payload is None else {name + ".zip": payload}
        try:
            splits, d = byod_block(uploaded, Path(td))
            extracted = sorted(p.name for p in d.iterdir())
            byod[name] = {"outcome": "accepted", "split_sizes": {k: len(v) for k, v in splits.items()},
                          "extracted_files": len(extracted)}
        except BaseException as exc:  # noqa: BLE001
            byod[name] = {"outcome": "error", "type": type(exc).__name__, "message": str(exc)[:200]}
results["byod_replay"] = byod
save()

# ---------------------------------------------------------------- stacked-adaptation probe (tiny random model)
import torch  # noqa: E402
torch.set_num_threads(2)
from transformers import Pix2StructConfig, Pix2StructForConditionalGeneration, Pix2StructProcessor  # noqa: E402
from pix2struct_ai2d_pipeline import DEFAULT_WEIGHTS_DIR, Pix2StructAI2DPipeline  # noqa: E402
from PIL import ImageDraw  # noqa: E402


def tiny(seed=0):
    processor = Pix2StructProcessor.from_pretrained(str(DEFAULT_WEIGHTS_DIR), local_files_only=True)
    processor.image_processor.max_patches = 64
    config = Pix2StructConfig.from_pretrained(str(DEFAULT_WEIGHTS_DIR), local_files_only=True)
    t, v = config.text_config, config.vision_config
    t.hidden_size, t.d_kv, t.num_heads, t.d_ff, t.num_layers = 32, 8, 4, 64, 3
    v.hidden_size, v.d_kv, v.num_attention_heads, v.d_ff = 32, 8, 4, 64
    v.num_hidden_layers = 2
    config.text_config, config.vision_config = t, v
    torch.manual_seed(seed)
    return Pix2StructAI2DPipeline._from_model(Pix2StructForConditionalGeneration(config), processor, "cpu", "tiny-random")


work = Path(tempfile.mkdtemp())
colours = ["red", "green", "blue", "yellow"]
records = []
for i in range(12):
    im = Image.new("RGB", (256, 192), "white")
    dr = ImageDraw.Draw(im)
    dr.rectangle([80, 30, 176, 126], fill=colours[i % 4])
    p = work / f"d{i}.png"
    im.save(p)
    records.append({"id": f"d{i:02d}", "image_id": f"d{i}", "image": str(p), "question": "What colour is the shape?",
                    "options": colours, "answer": i % 4, "category": "text-option"})
train, val = records[:8], records[8:]

pipe = tiny()
base = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
LR = 1e-3  # large lr so a random tiny model's weights move visibly in one epoch
r1 = pipe.adapt(train, None, epochs=1, lr=LR, batch_size=4, trainable_decoder_layers=2)  # no val split: selection keeps the final epoch, so weights move
after1 = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
# Notebook's "Optional experiment": set TRAINABLE_DECODER_LAYERS = 1 and rerun Section 7 (same pipe).
r2 = pipe.adapt(train, None, epochs=1, lr=LR, batch_size=4, trainable_decoder_layers=1)
after2 = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
layer1 = [k for k in base if k.startswith("decoder.layer.1.")]
changed = lambda a, b, keys: sum(not torch.equal(a[k], b[k]) for k in keys)  # noqa: E731
art = work / "adapter"
pipe.save_artifact(art)
fresh = tiny()
fresh.load_artifact(art)
missing_layer_names = [k for k in layer1]
fs = fresh._model.state_dict()
mismatch = [k for k in after2 if not torch.equal(after2[k].cpu(), fs[k].cpu())]
results["stacked_adaptation"] = {
    "scale": "REDUCED: 3-layer/32-wide random Pix2Struct, 8 train tiny drawings, no validation split (selection = final epoch so weights move; the notebook passes a validation split), CPU, lr=1e-3, 1 epoch each",
    "run1": {"trainable_decoder_layers": 2, "best_epoch": r1["best_epoch"], "n_trainable": r1["n_trainable"]},
    "run2": {"trainable_decoder_layers": 1, "best_epoch": r2["best_epoch"], "n_trainable": r2["n_trainable"],
             "epoch0_note": r2["history"][0].get("note")},
    "decoder_layer1_tensors_changed_vs_base_after_run2": changed(base, after2, layer1),
    "decoder_layer1_tensor_count": len(layer1),
    "run1_changed_tensors_vs_base": sum(not torch.equal(base[k], after1[k]) for k in base),
    "run2_started_from_base": all(torch.equal(base[k], after1[k]) for k in base),
    "artifact_tensors": len(json.loads((art / "manifest.json").read_text())["tensors"]),
    "artifact_layers_recorded": json.loads((art / "manifest.json").read_text())["adapter"]["trainable_decoder_layers"],
    "reloaded_vs_inmemory_mismatched_tensors": len(mismatch),
    "reloaded_vs_inmemory_mismatched_examples": mismatch[:5],
    "interpretation": "pipe.adapt starts from the pipeline's current weights and labels epoch 0 'frozen model'; after a second adapt() with fewer layers the in-memory model carries first-run changes in tensors the new artifact does not export, so the artifact no longer reproduces the in-memory model",
}
save()
print(json.dumps(results, indent=2, default=str)[:6000])
